//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
//" Script Title       : 
//"                      
//" Script Date        : Wed May 10 14:03:26 2017
//"                       
//"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

function Action()
{
	web.addCookie('currency=EUR; DOMAIN=172.16.44.19');

	web.addCookie('__atuvc=9%7C15%2C15%7C16%2C0%7C17%2C1%7C18%2C3%7C19; DOMAIN=172.16.44.19');

	web.addCookie('language=en; DOMAIN=172.16.44.19');

	web.addCookie('__atuvs=5912eee00c3b7afe000; DOMAIN=172.16.44.19');

	web.regFind(
		{
			text : 'Your Store'
		}
	);

	web.addCookie('SRCHUID=V=2&GUID=929B6FA041A640DFACCBCF7DC0980197; DOMAIN=www.bing.com');

	web.addCookie('SRCHD=AF=NOFORM; DOMAIN=www.bing.com');

	web.addCookie('SRCHUSR=DOB=20170405; DOMAIN=www.bing.com');

	web.url(
		{
			name : 'oc', 
			url : 'http://172.16.44.19/oc/', 
			resource : 0, 
			recContentType : 'text/html', 
			referer : '', 
			snapshot : 't1.inf', 
			mode : 'HTML', 
			extraRes :  [
				{url : 'http://www.bing.com/favicon.ico', referer : ''}
			]
		}
	);

	return 0;
}

