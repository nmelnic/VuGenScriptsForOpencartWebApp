Action()
{

	web_add_cookie("language=en-gb; DOMAIN=172.16.44.21");

	web_add_cookie("currency=USD; DOMAIN=172.16.44.21");

	web_add_cookie("__atuvc=1%7C19; DOMAIN=172.16.44.21");

	web_reg_find("Text=Your Store", 
		LAST);

	web_add_cookie("SRCHUID=V=2&GUID=929B6FA041A640DFACCBCF7DC0980197; DOMAIN=www.bing.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUSR=DOB=20170405; DOMAIN=www.bing.com");

	web_url("oc", 
		"URL=http://172.16.44.21/oc", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/DXI1ORHCpsQm3Vp6mXoaTXhCUOGz7vYGh680lGh-uXM.woff", "Referer=http://172.16.44.21/oc/", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/cJZKeOuBrn4kERxqtaUH3T8E0i7KZn-EPnyo3HZu7kw.woff", "Referer=http://172.16.44.21/oc/", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/k3k702ZOKiLJc3WVjuplzHhCUOGz7vYGh680lGh-uXM.woff", "Referer=http://172.16.44.21/oc/", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/opensans/v13/xjAJXh38I15wypJXxuGMBobN6UDyHWBl620a-IRfuBk.woff", "Referer=http://172.16.44.21/oc/", ENDITEM, 
		"Url=/oc/catalog/view/javascript/font-awesome/fonts/fontawesome-webfont.eot?", "Referer=http://172.16.44.21/oc/", ENDITEM, 
		"Url=http://www.bing.com/favicon.ico", "Referer=", ENDITEM, 
		LAST);

	return 0;
}